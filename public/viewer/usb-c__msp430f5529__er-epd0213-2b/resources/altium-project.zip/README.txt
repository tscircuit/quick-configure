usb_c__msp430f5529__er_epd0213_2b — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open usb_c__msp430f5529__er_epd0213_2b.PrjPcb in Altium Designer.