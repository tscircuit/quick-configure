# DDR Breakouts

Install with `npm ci --force`, then run `bun scripts/build-ddr-artifacts.ts`.

The Right configuration preserves the staged DDR fanout and fixed decoupling copper from tscircuit/core's progressive-fanout reference.
