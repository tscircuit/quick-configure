# DDR Breakouts · right

Routing status: **routed**.

Install with `npm ci --force`, then run `bun scripts/build-ddr-artifacts.ts right`.

The Right configuration preserves the staged DDR fanout and fixed decoupling copper from tscircuit/core's progressive-fanout reference.

Top preserves the 02-top-center placement, netlist, and bus directions from https://github.com/tscircuit/dataset-fanout31-am62l/tree/8c73befb36b125c84651c07454a9b940b3c6500a. It is an unrouted reference: the preview shows connection guides, not PCB traces. The dataset disables RAM routing and board-level routing; CPU fanout is an unsolved benchmark. To attempt CPU fanout, render Am62lLpddr4Top({ routingDisabled: false }) separately. This does not produce a fully routed board.
