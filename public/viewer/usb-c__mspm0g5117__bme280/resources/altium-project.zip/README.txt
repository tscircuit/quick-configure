usb_c__mspm0g5117__bme280 — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open usb_c__mspm0g5117__bme280.PrjPcb in Altium Designer.