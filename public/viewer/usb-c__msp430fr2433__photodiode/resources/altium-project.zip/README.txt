usb_c__msp430fr2433__photodiode — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open usb_c__msp430fr2433__photodiode.PrjPcb in Altium Designer.