usb_micro__msp430f5529__photodiode — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open usb_micro__msp430f5529__photodiode.PrjPcb in Altium Designer.