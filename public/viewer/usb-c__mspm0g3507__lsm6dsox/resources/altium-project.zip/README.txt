usb_c__mspm0g3507__lsm6dsox — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open usb_c__mspm0g3507__lsm6dsox.PrjPcb in Altium Designer.