usb_c__mspm0g5117__veml7700 — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open usb_c__mspm0g5117__veml7700.PrjPcb in Altium Designer.