usb_c__mspm0g5187__lis3dh — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open usb_c__mspm0g5187__lis3dh.PrjPcb in Altium Designer.