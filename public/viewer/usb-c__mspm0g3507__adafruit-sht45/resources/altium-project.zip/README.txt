usb_c__mspm0g3507__adafruit_sht45 — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open usb_c__mspm0g3507__adafruit_sht45.PrjPcb in Altium Designer.