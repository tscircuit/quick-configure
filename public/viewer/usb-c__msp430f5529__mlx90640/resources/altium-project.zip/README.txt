usb_c__msp430f5529__mlx90640 — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open usb_c__msp430f5529__mlx90640.PrjPcb in Altium Designer.