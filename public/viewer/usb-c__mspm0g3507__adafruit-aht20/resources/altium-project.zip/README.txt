usb_c__mspm0g3507__adafruit_aht20 — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open usb_c__mspm0g3507__adafruit_aht20.PrjPcb in Altium Designer.