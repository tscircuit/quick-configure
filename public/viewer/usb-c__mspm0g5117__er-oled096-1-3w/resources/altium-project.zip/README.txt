usb_c__mspm0g5117__er_oled096_1_3w — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open usb_c__mspm0g5117__er_oled096_1_3w.PrjPcb in Altium Designer.