usb_c__mspm33c321a__photodiode — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open usb_c__mspm33c321a__photodiode.PrjPcb in Altium Designer.