usb_c__msp430f5529__er_tft028a2_4 — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open usb_c__msp430f5529__er_tft028a2_4.PrjPcb in Altium Designer.