jst_sh__msp430g2553__photodiode — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open jst_sh__msp430g2553__photodiode.PrjPcb in Altium Designer.